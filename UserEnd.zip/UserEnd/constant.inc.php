
<?php
define('SITE_NAME','My Restuarant');
define('FRONT_SITE_NAME','Food Ordering');
define('FRONT_SITE_PATH','http://127.0.0.1/Restuarant/UserEnd/');


define('SERVER_IMAGE',$_SERVER['DOCUMENT_ROOT'].'/Restuarant/Admin/');
define('SERVER_DISH_IMAGE',SERVER_IMAGE.'media/dish');

define('SITE_IMAGE','http://localhost:100/Restuarant/Admin/');
define('SITE_DISH_IMAGE',SITE_IMAGE.'media/dish');

?>