<?php
session_start();
echo '<pre>';
unset($_SESSION['cart']);

?>