<?php
//host,username,password,DB_name
$con=mysqli_connect('localhost:3308','root','zuni','restuarant');
?>